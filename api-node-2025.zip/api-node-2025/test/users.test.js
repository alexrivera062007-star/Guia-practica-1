// Tests de la API sin base de datos: se reemplazan los métodos del modelo por dobles en memoria.
const { test, beforeEach, after } = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');

const User = require('../models/userModel');
const db = require('../db');
const app = require('../app');

let users;
beforeEach(() => {
  users = [{ id: 1, name: 'Ana', email: 'ana@mail.com' }];
  User.getAll = async () => users;
  User.getById = async (id) => users.find((u) => u.id === id) || null;
  User.create = async (data) => {
    const id = users.length + 1;
    users.push({ id, ...data });
    return id;
  };
  User.update = async (id, data) => {
    const u = users.find((x) => x.id === id);
    if (u) Object.assign(u, data);
    return Boolean(u);
  };
  User.delete = async (id) => {
    const before = users.length;
    users = users.filter((u) => u.id !== id);
    return users.length < before;
  };
});

after(() => db.end());

test('GET /api/users lista usuarios', async () => {
  const res = await request(app).get('/api/users').expect(200);
  assert.equal(res.body.length, 1);
});

test('GET /api/users/:id devuelve 404 si no existe', async () => {
  await request(app).get('/api/users/99').expect(404);
});

// --- Pruebas propias exigidas por el Paso 13 ---

// (a) id no numérico devuelve 400
test('GET /api/users/:id con id no numérico devuelve 400', async () => {
  const res = await request(app).get('/api/users/abc').expect(400);
  assert.ok(res.body.errors.length > 0);
});

// (b) el POST ignora los campos id y role (defensa contra mass assignment)
test('POST /api/users ignora los campos id y role', async () => {
  const res = await request(app)
    .post('/api/users')
    .send({ name: 'Luis', email: 'luis@mail.com', role: 'admin', id: 999 })
    .expect(201);
  assert.equal(res.body.id, 2); // asignado por el modelo, no por el cliente
  assert.equal(res.body.role, undefined);
});

// (c) un email duplicado devuelve 409 (se simula el error de MySQL)
test('POST /api/users con email duplicado devuelve 409', async () => {
  User.create = async () => {
    const err = new Error('Duplicate entry');
    err.code = 'ER_DUP_ENTRY';
    throw err;
  };
  const res = await request(app)
    .post('/api/users')
    .send({ name: 'Ana 2', email: 'ana@mail.com' })
    .expect(409);
  assert.equal(res.body.error, 'Ya existe un usuario con ese email');
});

// (d) un error interno responde 500 con mensaje genérico, sin detalles de SQL
test('Un error inesperado del modelo responde 500 sin detalles internos', async () => {
  User.getAll = async () => {
    throw new Error('ER_BAD_FIELD_ERROR: Unknown column "x" in "field list"');
  };
  const res = await request(app).get('/api/users').expect(500);
  assert.equal(res.body.error, 'Error interno del servidor');
  assert.ok(!JSON.stringify(res.body).includes('ER_BAD_FIELD_ERROR'));
});
